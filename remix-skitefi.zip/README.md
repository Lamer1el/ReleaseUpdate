# Skitefi — Профессиональный аппаратный Android-бенчмарк

Skitefi — высокоточный инструмент комплексного тестирования аппаратных возможностей мобильных устройств на базе Android, выполненный в строгом соответствии с концепцией **Material You / Material Design 3**.

---

## Ключевые возможности

1. **Автономное тестирование (100% Offline-First)**:
   - Все вычислительные алгоритмы работают локально, без необходимости подключения к интернету или наличия учетной записи.
   - **CPU**: Однопоточный и многопоточный стресс-тесты, раздельное измерение целочисленной и вещественной арифметики, прогрев ядер.
   - **GPU**: Нативный аппаратно-ускоренный рендеринг dynamic particle system и 3D-проекций с замером FPS, frame time и доли медленных кадров (<30 FPS).
   - **RAM**: Выделение прямого буфера памяти (`ByteBuffer.allocateDirect`), измерение пропускной способности последовательного чтения, записи, блочного копирования и задержек.
   - **Storage**: Последовательное и случайное (4KB) чтение/запись, расчет IOPS во временном файле приватной директории с автоматической очисткой и защитой накопителя.
   - **Stability & Throttling**: Длительный циклический тест устойчивости под нагрузкой с детекцией деградации производительности.
   - **Display & Battery**: Режимы экрана (60/90/120 Гц), плотность, температура батареи и ток зарядки через Android API.

2. **Персонализация Material 3**:
   - Поддержка Dynamic Color (Material You на Android 12+).
   - Ручной выбор акцентных палитр: Electric Blue, Emerald, Amber, Crimson, Purple, Cyan.
   - Светлая, темная и системная темы.
   - Настройка скругления карточек (8dp, 16dp, 24dp) с динамическим предпросмотром.
   - Импорт сторонних шрифтов TTF/OTF через безопасный системный Storage Access Framework.
   - Векторные SVG-иконки без использования эмодзи и растровых заглушек.

3. **Локальная база данных (Room)**:
   - Сохранение полной истории запусков и сырых физических метрик.
   - Фильтрация по категориям и текстовый поиск.
   - Сравнение любых двух запусков с расчетом процентной разницы.
   - Экспорт результатов в форматы JSON и CSV.

4. **GitHub Releases Patcher**:
   - Автоматическая и ручная проверка обновлений через GitHub REST API:
     `https://github.com/Lamer1el/ReleaseUpdate`
   - Семантическое версионирование (`VersionTriple`).
   - Потоковая загрузка APK с прогресс-баром в кэш приложения.
   - Проверка сигнатур, package name, кода версии и SHA-256 перед запуском системного `PackageInstaller` через `FileProvider`.

5. **Облачный бэкенд и рейтинг (Firebase)**:
   - Авторизация через Google Sign-In с актуальным Android Jetpack `CredentialManager`.
   - Публичные профили и атомарная бронь уникального никнейма в Firestore.
   - Глобальная таблица лидеров по категориям с пагинацией и верификацией.
   - Фоновая синхронизация отложенных результатов через `WorkManager`.

---

## Архитектура проекта

```
com.example
├── MainActivity.kt                # Навигация, Scaffold, Edge-to-Edge
├── SkitefiApplication.kt          # Инициализация каналов уведомлений и фоновых задач
├── benchmark/
│   ├── BenchmarkEnums.kt          # Категории и статусы валидации
│   ├── BenchmarkMetrics.kt        # Метрики и формула ScoringEngine v1.0
│   ├── BenchmarkEngine.kt         # Алгоритмы CPU, RAM, Storage, Stability
│   └── DeviceInfoProvider.kt      # Сбор аппаратных характеристик
├── data/
│   ├── local/                     # Room Database (BenchmarkEntity, Dao, AppDatabase)
│   ├── preferences/               # DataStore UserPreferencesRepository
│   └── remote/                    # Retrofit GitHub API, FirebaseRepository
├── notification/
│   └── NotificationHelper.kt      # Каналы уведомлений и POST_NOTIFICATIONS
├── sync/
│   ├── SyncWorker.kt              # Фоновая синхронизация с Firestore
│   └── UpdateCheckWorker.kt       # Фоновая проверка релизов GitHub
├── updater/
│   └── UpdateManager.kt           # Загрузка, валидация и установка APK
└── ui/
    ├── BenchmarkViewModel.kt      # Центральное состояние и бизнес-логика
    ├── components/                # BenchmarkGauge, GpuStressScene, SkitefiIcon
    ├── screens/                   # Home, Tests, History, Leaderboard, Settings, Onboarding, DeviceInfo, Updater
    └── theme/                     # Material 3 Color, Theme, Type
```

---

## Настройка Firebase и Google Sign-In

Если вы хотите активировать облачный рейтинг и синхронизацию:

1. **Создайте проект в Firebase Console**:
   - Перейдите в [Firebase Console](https://console.firebase.google.com/).
   - Добавьте Android-приложение с Package Name `com.aistudio.skitefi.bench`.
   - Сгенерируйте SHA-1 и SHA-256 отпечатки ключа подписи:
     ```bash
     keytool -list -v -keystore ./debug.keystore -alias androiddebugkey -storepass android -keypass android
     ```
   - Зарегистрируйте отпечатки SHA-1 и SHA-256 в настройках проекта Firebase.
   - Скачайте `google-services.json` и поместите его в папку `app/`.

2. **Включение Google Sign-In**:
   - В разделе **Authentication** включите провайдер **Google**.
   - Скопируйте **Web Client ID** из настроек Google-провайдера в консоли Firebase.

3. **Развертывание правил безопасности Firestore**:
   - Установите Firebase CLI: `npm install -g firebase-tools`
   - Войдите: `firebase login`
   - Разверните правила и индексы:
     ```bash
     firebase deploy --only firestore:rules,firestore:indexes
     ```

4. **Развертывание Cloud Functions (TypeScript)**:
   - Перейдите в папку `functions/`:
     ```bash
     cd functions
     npm install
     npm run build
     firebase deploy --only functions
     ```

---

## Публикация обновлений на GitHub

Приложение настроено на мониторинг репозитория:
`https://github.com/Lamer1el/ReleaseUpdate`

1. Соберите релизный APK:
   ```bash
   gradle assembleRelease
   ```
2. Создайте релиз на GitHub с тегом в формате `v1.0.1` или `v1.1.0`.
3. Прикрепите скомпилированный `.apk` файл к релизу (в секцию Assets).
4. Пользователи приложения получат уведомление и смогут загрузить и обновить приложение в один клик.

---

## Сборка и тестирование

- **Запуск модульных тестов**:
  ```bash
  gradle :app:testDebugUnitTest
  ```
- **Сборка APK для отладки**:
  ```bash
  gradle :app:assembleDebug
  ```
